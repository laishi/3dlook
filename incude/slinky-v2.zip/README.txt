A Pen created at CodePen.io. You can find this one at http://codepen.io/laishi/pen/qdaxYy.

 No jQuery dependency, section progress shown in headers, click to scroll, resizable with scrollbar on window.
Inspired by [Slinky.js](http://slinky.iclanzan.com/) and [DesignWall](http://www.designwall.com/guide/quick-start-installation/).

Currently doesn't work on iOS < 8 since they mess with scroll events. If you use this in production, look into [iScroll](http://www.frontendfrontline.com/2013/07/smooth-parallax-scrolling-on-ios-with.html).

Forked from [Riley Shaw](http://codepen.io/rileyjshaw/)'s Pen [Slinky V2](http://codepen.io/rileyjshaw/pen/pIFly/).