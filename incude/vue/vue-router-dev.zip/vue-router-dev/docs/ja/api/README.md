# API リファレンス

- [Router インスタンスプロパティ](properties.md)
- [router.start](start.md)
- [router.stop](stop.md)
- [router.map](map.md)
- [router.on](on.md)
- [router.go](go.md)
- [router.replace](replace.md)
- [router.redirect](redirect.md)
- [router.alias](alias.md)
- [router.beforeEach](before-each.md)
- [router.afterEach](after-each.md)
