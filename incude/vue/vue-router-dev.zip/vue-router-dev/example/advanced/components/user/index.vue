<template>
  <div>
    <h2>User yo</h2>
    <router-view></router-view>
  </div>
</template>
