A Pen created at CodePen.io. You can find this one at http://codepen.io/mjweaver01/pen/OMMaax.

 Playing around with Vue.js