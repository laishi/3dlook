A Pen created at CodePen.io. You can find this one at http://codepen.io/acemir/pen/YXzxJN.

 Pure CSS Loader concept based on a [Dribble](//drbl.in/nWkK) by [Jason Zigrino](//dribbble.com/JasonZigrino)